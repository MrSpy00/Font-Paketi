# oepncv-renk-nesne-takip
Sadece mavi rengi tanımladım nesne takip için 'örnresim.jpg' kısmına resimlerini tanımlamanız gerekmektedir. Transparent olmalıdır.
